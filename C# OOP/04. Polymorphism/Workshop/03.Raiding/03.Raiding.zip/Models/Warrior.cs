﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Raiding.Models
{
    internal class Warrior : Fighter
    {
        public Warrior(string name) : base(name)
        {
            Power = 100;
        }
    }
}
