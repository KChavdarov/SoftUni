﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WildFarm.Foods
{
    internal class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
}
