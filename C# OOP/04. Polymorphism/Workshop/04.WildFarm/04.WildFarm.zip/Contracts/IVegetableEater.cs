﻿using _04.WildFarm.Foods;
using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WildFarm.Contracts
{
    internal interface IVegetableEater
    {
        void Eat(Vegetable vegetable);

    }
}
