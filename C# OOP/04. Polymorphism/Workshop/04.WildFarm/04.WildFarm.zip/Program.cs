﻿using _04.WildFarm.Animals;
using _04.WildFarm.Animals.Mammals;
using _04.WildFarm.Foods;
using System;
using System.Collections.Generic;

namespace _04.WildFarm
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Animal> animals = new List<Animal>();
            string input = Console.ReadLine();

            while (input != "End")
            {
                string[] tokens = input.Split(' ');
                Animal animal = CreateAnimal(tokens);
                animals.Add(animal);

                tokens = Console.ReadLine().Split(' ');
                Food food = CreateFood(tokens[0], int.Parse(tokens[1]));

                try
                {
                    Console.WriteLine(animal.MakeSound());
                    animal.Eat(food);
                }
                catch (Exception err)
                {
                    Console.WriteLine(err.Message);
                }

                input = Console.ReadLine();
            }

            Console.WriteLine(String.Join(Environment.NewLine, animals));
        }
        static Animal CreateAnimal(string[] tokens)
        {
            string type = tokens[0];
            string name = tokens[1];
            double weight = double.Parse(tokens[2]);

            switch (type)
            {
                case "Cat":
                    {
                        string livingRegion = tokens[3];
                        string breed = tokens[4];
                        return new Cat(name, weight, livingRegion, breed);
                    }
                case "Tiger":
                    {
                        string livingRegion = tokens[3];
                        string breed = tokens[4];
                        return new Tiger(name, weight, livingRegion, breed);
                    }
                case "Dog":
                    {
                        string livingRegion = tokens[3];
                        return new Dog(name, weight, livingRegion);
                    }
                case "Mouse":
                    {
                        string livingRegion = tokens[3];
                        return new Mouse(name, weight, livingRegion);
                    }
                case "Hen":
                    {
                        double wingSize = double.Parse(tokens[3]);
                        return new Hen(name, weight, wingSize);
                    }
                case "Owl":
                    {
                        double wingSize = double.Parse(tokens[3]);
                        return new Owl(name, weight, wingSize);
                    }
                default:
                    return null;
            }

        }

        static Food CreateFood(string type, int quantity)
        {
            switch (type)
            {
                case "Vegetable":
                    return new Vegetable(quantity);
                case "Fruit":
                    return new Fruit(quantity);
                case "Meat":
                    return new Meat(quantity);
                case "Seeds":
                    return new Seeds(quantity);
                default:
                    return null;
            }
        }

    }
}
