﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06.FoodShortage
{
    internal interface IBuyer
    {
        string Name { get; }
        int Food { get; }
        int BuyFood();
    }
}
